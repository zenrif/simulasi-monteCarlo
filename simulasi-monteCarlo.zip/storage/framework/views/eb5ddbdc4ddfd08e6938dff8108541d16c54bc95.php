

<?php $__env->startSection('container'); ?>
<main class="main-content position-relative max-height-vh-100 h-100 border-radius-lg mt-4">
    <!-- Navbar -->
    <nav class="navbar navbar-main navbar-expand-lg px-0 mx-4 shadow-none border-radius-xl mt-4" id="navbarBlur"
        navbar-scroll="true">
        <div class="container-fluid py-1 px-3">
            <nav aria-label="breadcrumb">
                <h4 class="font-weight-bolder mb-2">Metode LCG</h4>
                <h6 class="font mb-1">Selamat datang</h6>
            </nav>
            <div class="collapse navbar-collapse mt-sm-0 mt-2 me-md-0 me-sm-4" id="navbar">
                <div class="ms-md-auto pe-md-3 d-flex align-items-center">
                </div>
                <ul class="navbar-nav justify-content-end">

                    <li class="nav-item d-xl-none ps-3 d-flex align-items-center">
                        <a href="javascript:;" class="nav-link text-body p-0" id="iconNavbarSidenav">
                            <div class="sidenav-toggler-inner">
                                <i class="sidenav-toggler-line"></i>
                                <i class="sidenav-toggler-line"></i>
                                <i class="sidenav-toggler-line"></i>
                            </div>
                        </a>
                    </li>

    </nav>
    <!-- End Navbar -->
    <div class="container">
        <div class="panel panel-primary">
            <div class="panel panel-primary">
                <div class="panel-heading">Input Data Permintaan</div>
                <div class="panel-body">
                    <div class="input-group">
                        <h1>
                            <center>Tahap 1</center>
                        </h1>
                        <p>
                            <center>Silahkan masukan data permintaan</center>
                        </p>
                        <form action="/proses_2" method="post">
                            <div class="table table-responsive">
                                <table class="table table-hover custom-table-header">
                                    <tr>
                                        <th>Permintaan</th>
                                        <th>Frekuensi</th>
                                    <tr>
                                        <?php for ($i = 0; $i < $jumlah; $i++) : ?>
                                    <tr>
                                        <td><input type=number min=0 name=demand[] placeholder="0" class="form-control"
                                                required="" oninvalid="this.setCustomValidity('Harap di isi !')"
                                                oninput="setCustomValidity('')"></td>
                                        <td><input type=number min=1 name=freq[] placeholder="0" class="form-control"
                                                required="" oninvalid="this.setCustomValidity('Harap di isi !')"
                                                oninput="setCustomValidity('')"></td>
                                    </tr>
                                    <?php endfor; ?>
                                </table>
                                <div class="input-group-btn">
                                    <input type="hidden" name="jumlah" value="<?php echo $jumlah; ?>">
                                    <center><input type="submit" value="Hitung" name="submit" class="btn btn-success"
                                            style="padding-left: 30px; padding-right: 30px;"></center>
                                </div>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>
    </div>
</main>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\anyone\Documents\Kuliah\RO\simulasi-monteCarlo\resources\views/prediksi/proses_1.blade.php ENDPATH**/ ?>